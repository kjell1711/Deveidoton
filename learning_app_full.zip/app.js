import { initializeApp } from "https://www.gstatic.com/firebasejs/12.5.0/firebase-app.js";
  import { getFirestore, doc, getDoc, setDoc, updateDoc } from "https://www.gstatic.com/firebasejs/12.5.0/firebase-firestore.js";

  const firebaseConfig = {
    apiKey: "AIzaSyBXZG4vsRDqpe_XRHeb64MV-NbLbKtijWs",
    authDomain: "eidoton.firebaseapp.com",
    projectId: "eidoton",
    storageBucket: "eidoton.firebasestorage.app",
    messagingSenderId: "167879420438",
    appId: "1:167879420438:web:f0c10f3a042eb37a1da337",
    measurementId: "G-GCBC06PE3R"
  };

  let db;
  try {
    const firebaseApp = initializeApp(firebaseConfig);
    db = getFirestore(firebaseApp);
    console.log("Firebase initialisiert!");
  } catch (error) {
    console.error("Firebase Fehler:", error);
  }

  

  

  const appElement = document.getElementById('app');

  // === Helper Functions ===
  
  function shuffleArray(array) {
    const arr = [...array];
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  }

  function getRandomQuestion(subject) {
    const questions = configData.questions[subject];
    const q = questions[Math.floor(Math.random() * questions.length)];
    // Shuffle answers
    const shuffledAnswers = shuffleArray(q.answers.map((ans, idx) => ({ text: ans, originalIndex: idx })));
    return {
      question: q.question,
      answers: shuffledAnswers.map(a => a.text),
      correct: shuffledAnswers.findIndex(a => a.originalIndex === q.correct)
    };
  }

  // === Firebase Functions ===
  
  async function loadNewsFromFirebase() {
    try {
      const newsDocRef = doc(db, "app_config", "news");
      const newsDoc = await getDoc(newsDocRef);
      if (newsDoc.exists()) {
        return newsDoc.data().text || '';
      } else {
        return 'Keine aktuellen Infos verfügbar.';
      }
    } catch (error) {
      console.error("Firebase Fehler beim Laden der News:", error);
      return 'Fehler beim Laden der Infos.';
    }
  }

  async function loadUserFromFirebase(name) {
    try {
      const normalizedName = name.toLowerCase();
      const userDocRef = doc(db, "users", normalizedName);
      const userDoc = await getDoc(userDocRef);
      
      if (userDoc.exists()) {
        return userDoc.data();
      } else {
        return null; // User existiert nicht
      }
    } catch (error) {
      console.error("Firebase Fehler beim Laden:", error);
      return null;
    }
  }

  async function createUserInFirebase(name, pin) {
    try {
      const normalizedName = name.toLowerCase();
      const now = new Date().toISOString();
      const newUser = {
        name: name,
        pin: pin,
        coins: 0,
        richtig: 0,
        falsch: 0,
        highscore: 0,
        ban: false,
        banReason: "",
        accountCreated: now,
        lastLogin: now,
        totalLogins: 1
      };
      const userDocRef = doc(db, "users", normalizedName);
      await setDoc(userDocRef, newUser);
      return newUser;
    } catch (error) {
      console.error("Firebase Fehler beim Erstellen:", error);
      return null;
    }
  }

  async function updateLoginStats() {
    if (!state.userId) return;
    try {
      const normalizedUserId = state.userId.toLowerCase();
      const userDocRef = doc(db, "users", normalizedUserId);
      const userDoc = await getDoc(userDocRef);
      
      if (userDoc.exists()) {
        const currentLogins = userDoc.data().totalLogins || 0;
        await updateDoc(userDocRef, {
          lastLogin: new Date().toISOString(),
          totalLogins: currentLogins + 1
        });
      }
    } catch (error) {
      console.error("Firebase Fehler beim Update Login Stats:", error);
    }
  }

  async function saveUserToFirebase() {
    if (!state.userId) return;
    try {
      const normalizedUserId = state.userId.toLowerCase();
      const userDocRef = doc(db, "users", normalizedUserId);
      await updateDoc(userDocRef, {
        coins: state.userCoins,
        richtig: state.userRichtig,
        falsch: state.userFalsch,
        highscore: state.userHighscore
      });
    } catch (error) {
      console.error("Firebase Fehler beim Speichern:", error);
    }
  }

  // === Auth Actions ===
  
  async function handleUsernameSubmit() {
    const input = state.loginInput.trim();
    if (!input) return;
    
    const userData = await loadUserFromFirebase(input);
    
    if (userData) {
      // User existiert - PIN Login
      state.tempUserData = userData;
      state.authStep = 'pin-login';
      state.pin = '';
    } else {
      // Neuer User - PIN erstellen
      state.tempUserData = { name: input };
      state.authStep = 'pin-new';
      state.pin = '';
    }
    render();
  }

  function handlePinInput(digit) {
    if (state.pin.length < 4) {
      state.pin += digit;
      render();
      
      if (state.pin.length === 4) {
        setTimeout(() => handlePinComplete(), 300);
      }
    }
  }

  function handlePinDelete() {
    if (state.pin.length > 0) {
      state.pin = state.pin.slice(0, -1);
      render();
    }
  }

  async function handlePinComplete() {
    if (state.authStep === 'pin-new') {
      // Neuen User erstellen
      const newUser = await createUserInFirebase(state.tempUserData.name, state.pin);
      if (newUser) {
        await loginUser(newUser);
      }
    } else if (state.authStep === 'pin-login') {
      // PIN überprüfen
      if (state.pin === state.tempUserData.pin) {
        await loginUser(state.tempUserData);
      } else {
        // Falscher PIN
        state.pin = '';
        alert('Falscher PIN! Bitte versuche es erneut.');
        render();
      }
    }
  }

  async function loginUser(userData) {
    if (userData.ban === true) {
      state.isBanned = true;
      state.banReason = userData.banReason || "Kein Grund angegeben";
      state.userName = userData.name;
      render();
      return;
    }
    
    const newsData = await loadNewsFromFirebase();
    
    state.userName = userData.name;
    state.userCoins = userData.coins || 0;
    state.userRichtig = userData.richtig || 0;
    state.userFalsch = userData.falsch || 0;
    state.userHighscore = userData.highscore || 0;
    state.newsText = newsData;
    state.userId = userData.name;
    state.isLoggedIn = true;
    state.isBanned = false;
    state.currentQuestion = getRandomQuestion('mathe');
    
    await updateLoginStats();
    render();
  }

  function handleLogout() {
    state.isLoggedIn = false;
    state.userName = '';
    state.userCoins = 0;
    state.userRichtig = 0;
    state.userFalsch = 0;
    state.userHighscore = 0;
    state.userId = null;
    state.loginInput = '';
    state.authStep = 'username';
    state.pin = '';
    state.tempUserData = null;
    state.currentTab = 'mathe';
    state.currentQuestion = null;
    state.feedback = null;
    stopFlappyBird();
    render();
  }

  // === Question Actions ===
  
  async function handleAnswer(index) {
    if (!state.currentQuestion || state.feedback) return;
    const isCorrect = index === state.currentQuestion.correct;
    if (isCorrect) {
      state.userCoins += 1;
      state.userRichtig += 1;
      state.feedback = 'correct';
      await saveUserToFirebase();
    } else {
      state.userFalsch += 1;
      state.feedback = 'wrong';
      await saveUserToFirebase();
    }

    render();
    setTimeout(() => {
      state.feedback = null;
      if (!['spiele','profil'].includes(state.currentTab)) {
        state.currentQuestion = getRandomQuestion(state.currentTab);
      }
      render();
    }, 1500);
  }

  function handleTabChange(tab) {
    state.currentTab = tab;
    state.feedback = null;
    if (['mathe','deutsch','englisch'].includes(tab)) {
      state.currentQuestion = getRandomQuestion(tab);
    } else {
      state.currentQuestion = null;
    }
    render();
  }

  // === Flappy Bird Game ===
  
  let canvas, ctx;
  const GRAVITY = 0.4;
  const JUMP_STRENGTH = -8;
  const PIPE_WIDTH = 60;
  const PIPE_GAP = 150;
  const PIPE_SPEED = 3;

  async function startFlappyBird() {
    if (state.userCoins < 2) return;
    
    state.userCoins -= 2;
    await saveUserToFirebase();
    
    state.gameActive = true;
    state.gameOver = false;
    state.gameScore = 0;
    state.bird = { y: 150, velocity: 0 };
    state.pipes = [];
    
    render();
    
    // Wait for canvas to be rendered
    setTimeout(() => {
      canvas = document.getElementById('gameCanvas');
      if (!canvas) return;
      ctx = canvas.getContext('2d');
      gameLoop();
    }, 100);
  }

  function gameLoop() {
    if (!state.gameActive || !canvas) return;
    
    // Update bird
    state.bird.velocity += GRAVITY;
    state.bird.y += state.bird.velocity;
    
    // Check ground/ceiling collision
    if (state.bird.y > 350 || state.bird.y < 0) {
      endFlappyBird();
      return;
    }
    
    // Update pipes
    state.pipes.forEach(pipe => {
      pipe.x -= PIPE_SPEED;
      
      // Check collision
      if (pipe.x < 100 && pipe.x > 20) {
        if (state.bird.y < pipe.top || state.bird.y > pipe.top + PIPE_GAP) {
          endFlappyBird();
          return;
        }
      }
      
      // Score when passing pipe
      if (!pipe.scored && pipe.x < 50) {
        pipe.scored = true;
        state.gameScore++;
      }
    });
    
    // Remove off-screen pipes
    state.pipes = state.pipes.filter(p => p.x > -PIPE_WIDTH);
    
    // Add new pipes
    if (state.pipes.length === 0 || state.pipes[state.pipes.length - 1].x < 200) {
      const topHeight = 50 + Math.random() * 150;
      state.pipes.push({
        x: 400,
        top: topHeight,
        scored: false
      });
    }
    
    // Draw
    drawFlappyBird();
    
    state.gameFrameId = requestAnimationFrame(gameLoop);
  }

  function drawFlappyBird() {
    if (!ctx) return;
    
    // Clear
    ctx.fillStyle = '#87CEEB';
    ctx.fillRect(0, 0, 400, 400);
    
    // Draw pipes
    ctx.fillStyle = '#22C55E';
    state.pipes.forEach(pipe => {
      // Top pipe
      ctx.fillRect(pipe.x, 0, PIPE_WIDTH, pipe.top);
      // Bottom pipe
      ctx.fillRect(pipe.x, pipe.top + PIPE_GAP, PIPE_WIDTH, 400 - pipe.top - PIPE_GAP);
    });
    
    // Draw bird
    ctx.fillStyle = '#FBBF24';
    ctx.beginPath();
    ctx.arc(60, state.bird.y, 15, 0, Math.PI * 2);
    ctx.fill();
    
    // Draw score
    ctx.fillStyle = '#1F2937';
    ctx.font = 'bold 24px sans-serif';
    ctx.fillText(`Score: ${state.gameScore}`, 10, 30);
  }

  function jumpBird() {
    if (state.gameActive) {
      state.bird.velocity = JUMP_STRENGTH;
    }
  }

  async function endFlappyBird() {
    if (!state.gameActive) return;
    
    state.gameActive = false;
    state.gameOver = true;
    
    if (state.gameScore > state.userHighscore) {
      state.userHighscore = state.gameScore;
      await saveUserToFirebase();
    }
    
    if (state.gameFrameId) {
      cancelAnimationFrame(state.gameFrameId);
      state.gameFrameId = null;
    }
    
    render();
  }

  function stopFlappyBird() {
    state.gameActive = false;
    state.gameOver = false;
    if (state.gameFrameId) {
      cancelAnimationFrame(state.gameFrameId);
      state.gameFrameId = null;
    }
  }

  // === Render Functions ===
  
  function renderBanned() {
    return `
      <div class="flex items-center justify-center min-h-screen bg-gradient-to-br from-red-50 to-red-100 p-4">
        <div class="bg-white rounded-3xl shadow-2xl p-8 w-full max-w-md">
          <div class="text-center mb-8">
            <div class="inline-block p-4 bg-red-500 rounded-full mb-4 text-white text-4xl">🚫</div>
            <h1 class="text-3xl font-bold text-red-600 mb-2">Account gesperrt</h1>
            <p class="text-gray-600 mb-4">Dein Account wurde von einem Administrator gesperrt.</p>
            <div class="bg-red-50 rounded-2xl p-6 border-2 border-red-200">
              <p class="text-sm font-semibold text-red-800 mb-2">Grund:</p>
              <p class="text-red-700">${state.banReason}</p>
            </div>
          </div>
          <p class="text-center text-gray-500 text-sm">Wenn du denkst, dass dies ein Fehler ist, kontaktiere bitte einen Administrator.</p>
        </div>
      </div>
    `;
  }

  function renderLogin() {
    if (state.authStep === 'username') {
      return `
        <div class="flex items-center justify-center min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
          <div class="bg-white rounded-3xl shadow-2xl p-8 w-full max-w-md">
            <div class="text-center mb-8">
              <div class="inline-block p-4 bg-blue-500 rounded-full mb-4 text-white text-4xl">📚</div>
              <h1 class="text-3xl font-bold text-gray-800 mb-2">Willkommen!</h1>
              <p class="text-gray-600">Gib deinen Namen ein, um zu starten</p>
            </div>
            <input id="loginInput" type="text" value="" placeholder="Dein Name" class="w-full px-6 py-4 text-lg border-2 border-gray-300 rounded-2xl mb-4 focus:outline-none focus:border-blue-500 transition-colors" />
            <button id="loginBtn" class="w-full bg-blue-500 text-white py-4 rounded-2xl text-lg font-semibold hover:bg-blue-600 transition-colors shadow-lg">Weiter</button>
          </div>
        </div>
      `;
    } else if (state.authStep === 'pin-new' || state.authStep === 'pin-login') {
      const isNew = state.authStep === 'pin-new';
      return `
        <div class="flex items-center justify-center min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
          <div class="bg-white rounded-3xl shadow-2xl p-8 w-full max-w-md">
            <div class="text-center mb-8">
              <div class="inline-block p-4 bg-blue-500 rounded-full mb-4 text-white text-4xl">🔐</div>
              <h1 class="text-2xl font-bold text-gray-800 mb-2">${isNew ? 'PIN erstellen' : 'PIN eingeben'}</h1>
              <p class="text-gray-600 mb-6">${isNew ? 'Wähle einen 4-stelligen PIN' : 'Gib deinen PIN ein'}</p>
              
              <div class="flex justify-center gap-4 mb-8">
                ${[0,1,2,3].map(i => `<div class="pin-dot ${i < state.pin.length ? 'filled' : ''}"></div>`).join('')}
              </div>
            </div>
            
            <div class="grid grid-cols-3 gap-4 mb-4">
              ${[1,2,3,4,5,6,7,8,9].map(n => `
                <button class="pin-btn bg-gray-100 hover:bg-gray-200 active:bg-gray-300 text-2xl font-bold py-6 rounded-full transition-all" data-digit="${n}">${n}</button>
              `).join('')}
              <div></div>
              <button class="pin-btn bg-gray-100 hover:bg-gray-200 active:bg-gray-300 text-2xl font-bold py-6 rounded-full transition-all" data-digit="0">0</button>
              <button id="pinDelete" class="bg-red-100 hover:bg-red-200 active:bg-red-300 text-2xl py-6 rounded-full transition-all">⌫</button>
            </div>
          </div>
        </div>
      `;
    }
  }

  function renderHeader() {
    const title = state.currentTab === 'spiele' ? 'Spiele' : state.currentTab === 'profil' ? 'Profil' : state.currentTab === 'mathe' ? 'Mathe' : state.currentTab === 'deutsch' ? 'Deutsch' : 'Englisch';
    return `
      <div class="bg-white shadow-sm px-6 py-4 flex items-center justify-between">
        <h2 class="text-2xl font-bold text-gray-800 capitalize">${title}</h2>
        <div class="flex items-center gap-3">
          <div class="flex items-center bg-yellow-100 px-4 py-2 rounded-full">
            <span class="text-2xl mr-2">🪙</span>
            <span class="font-bold text-lg text-yellow-700" id="coinCount">${state.userCoins}</span>
          </div>
          ${state.currentTab === 'profil' ? `
            <button id="logoutBtn" class="bg-red-500 hover:bg-red-600 text-white p-3 rounded-xl transition-all shadow-lg">
              <span class="text-xl">🚪</span>
            </button>
          ` : ''}
        </div>
      </div>
    `;
  }

  function renderProfile() {
    return `
      <div class="max-w-2xl mx-auto">
        <div class="bg-white rounded-3xl shadow-lg p-8 text-center mb-6">
          <div class="w-24 h-24 bg-gradient-to-br from-blue-400 to-indigo-500 rounded-full mx-auto mb-4 flex items-center justify-center text-white text-3xl">👤</div>
          <h3 class="text-3xl font-bold text-gray-800 mb-2">${state.userName}</h3>
          <div class="flex items-center justify-center gap-3 mt-6 bg-yellow-50 py-4 px-6 rounded-2xl">
            <span class="text-4xl">🪙</span>
            <span class="text-3xl font-bold text-yellow-700">${state.userCoins} Münzen</span>
          </div>
          
          <div class="grid grid-cols-2 gap-4 mt-6">
            <div class="bg-green-50 p-4 rounded-2xl border-2 border-green-200">
              <div class="text-3xl mb-2">✅</div>
              <div class="text-2xl font-bold text-green-700">${state.userRichtig}</div>
              <div class="text-sm text-green-600">Richtig</div>
            </div>
            <div class="bg-red-50 p-4 rounded-2xl border-2 border-red-200">
              <div class="text-3xl mb-2">❌</div>
              <div class="text-2xl font-bold text-red-700">${state.userFalsch}</div>
              <div class="text-sm text-red-600">Falsch</div>
            </div>
          </div>
          
          <div class="bg-purple-50 p-4 rounded-2xl border-2 border-purple-200 mt-4">
            <div class="text-3xl mb-2">🏆</div>
            <div class="text-2xl font-bold text-purple-700">${state.userHighscore}</div>
            <div class="text-sm text-purple-600">Flappy Bird Highscore</div>
          </div>
        </div>
        
        <div class="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-3xl shadow-lg p-6 border-2 border-blue-200">
          <div class="flex items-center gap-2 mb-3">
            <span class="text-2xl">📢</span>
            <h4 class="text-xl font-bold text-gray-800">Neueste Infos</h4>
          </div>
          <p class="text-gray-700 text-lg leading-relaxed news-text">${state.newsText}</p>
        </div>
      </div>
    `;
  }

  function renderGameIntro() {
    return `
      <div class="max-w-2xl mx-auto">
        <div class="bg-white rounded-3xl shadow-lg p-8 text-center">
          <div class="text-yellow-500 text-6xl mb-4">🐦</div>
          <h3 class="text-2xl font-bold text-gray-800 mb-4">Flappy Bird</h3>
          <p class="text-gray-600 mb-6">Fliege durch die Röhren und sammle Punkte!</p>
          
          ${state.userHighscore > 0 ? `
            <div class="bg-purple-50 rounded-2xl p-4 mb-6 border-2 border-purple-200">
              <p class="text-sm text-purple-600 mb-1">Dein Highscore</p>
              <p class="text-3xl font-bold text-purple-700">🏆 ${state.userHighscore}</p>
            </div>
          ` : ''}
          
          <div class="bg-yellow-50 rounded-2xl p-6 mb-6">
            <p class="text-lg text-yellow-700 font-semibold mb-2">Kosten: 2 Münzen</p>
            <p class="text-sm text-yellow-600">Tippe oder klicke, um zu fliegen!</p>
            <p class="text-xs text-yellow-500 mt-2">Vermeide die grünen Röhren</p>
          </div>
          <button id="startGameBtn" class="w-full py-4 rounded-2xl text-lg font-semibold transition-colors ${state.userCoins>=2? 'bg-yellow-500 text-white hover:bg-yellow-600 shadow-lg' : 'bg-gray-300 text-gray-500 cursor-not-allowed'}">${state.userCoins>=2? 'Spiel starten!' : 'Nicht genug Münzen'}</button>
        </div>
      </div>
    `;
  }

  function renderGameActive() {
    return `
      <div class="max-w-2xl mx-auto">
        <div class="bg-white rounded-3xl shadow-lg p-6">
          <div class="mb-4 flex justify-between items-center">
            <div class="text-xl font-bold text-blue-600">Score: ${state.gameScore}</div>
            <button id="endGameBtn" class="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-xl font-semibold transition-all">Beenden</button>
          </div>
          <canvas id="gameCanvas" width="400" height="400" class="w-full cursor-pointer"></canvas>
          <p class="text-center text-gray-600 mt-4 text-sm">Tippe auf das Spiel, um zu fliegen!</p>
        </div>
      </div>
    `;
  }

  function renderGameOver() {
    return `
      <div class="max-w-2xl mx-auto">
        <div class="bg-white rounded-3xl shadow-lg p-8 text-center">
          <div class="text-6xl mb-4">💥</div>
          <h3 class="text-3xl font-bold text-gray-800 mb-4">Game Over!</h3>
          <div class="bg-blue-50 rounded-2xl p-6 mb-4">
            <p class="text-2xl font-bold text-blue-700 mb-2">${state.gameScore} Punkte</p>
          </div>
          ${state.gameScore === state.userHighscore && state.gameScore > 0 ? `
            <div class="bg-purple-50 rounded-2xl p-4 mb-6 border-2 border-purple-200">
              <p class="text-lg font-bold text-purple-700">🎉 Neuer Highscore! 🎉</p>
            </div>
          ` : ''}
          <button id="tryAgainBtn" class="w-full py-4 rounded-2xl text-lg font-semibold transition-colors ${state.userCoins>=2? 'bg-yellow-500 text-white hover:bg-yellow-600 shadow-lg' : 'bg-gray-300 text-gray-500 cursor-not-allowed'}">${state.userCoins>=2? 'Nochmal spielen!' : 'Nicht genug Münzen'}</button>
        </div>
      </div>
    `;
  }

  function renderQuestionCard() {
    if (!state.currentQuestion) return '';
    const answersHtml = state.currentQuestion.answers.map((a,i) => {
      const base = 'w-full p-6 text-xl font-medium rounded-2xl transition-all transform active:scale-95';
      let classes = 'bg-blue-50 text-blue-900 hover:bg-blue-100 border-2 border-blue-200';
      if (state.feedback === 'correct' && i === state.currentQuestion.correct) classes = 'bg-green-500 text-white shadow-lg';
      else if (state.feedback === 'wrong' && i === state.currentQuestion.correct) classes = 'bg-green-500 text-white shadow-lg';
      else if (state.feedback === 'wrong') classes = 'bg-red-100 text-red-700 border-2 border-red-300';
      return `<button data-ans="${i}" class="answerBtn ${base} ${classes}" ${state.feedback? 'disabled': ''}>${a}</button>`;
    }).join('');

    return `
      <div class="max-w-2xl mx-auto">
        <div class="bg-white rounded-3xl shadow-lg p-8 mb-6">
          <p class="text-2xl font-semibold text-gray-800 text-center mb-8">${state.currentQuestion.question}</p>
          <div class="space-y-4">${answersHtml}</div>
          ${state.feedback === 'correct' ? `<div class="mt-6 text-center"><p class="text-2xl font-bold text-green-600">Richtig! 🎉</p><p class="text-lg text-green-600 mt-2">+1 Münze</p></div>` : ''}
          ${state.feedback === 'wrong' ? `<div class="mt-6 text-center"><p class="text-2xl font-bold text-red-600">Leider falsch 😔</p><p class="text-lg text-gray-600 mt-2">Versuch's nochmal!</p></div>` : ''}
        </div>
      </div>
    `;
  }

  function renderBottomNav() {
    const c = state.currentTab;
    function cls(tab, color) { 
      const isActive = c === tab;
      return `flex flex-col items-center p-4 rounded-xl transition-all ${isActive ? color + ' tab-active' : 'text-gray-500'}`;
    }
    return `
      <div class="fixed bottom-0 left-0 right-0 bg-white border-t-2 border-gray-200 shadow-lg">
        <div class="flex justify-around items-center py-1 max-w-2xl mx-auto">
          <button data-tab="spiele" class="${cls('spiele','text-purple-600')}">
            <div class="text-3xl mb-1">🎮</div>
            <span class="text-xs font-semibold">Spiele</span>
          </button>
          <button data-tab="mathe" class="${cls('mathe','text-blue-600')}">
            <div class="text-3xl mb-1">🔢</div>
            <span class="text-xs font-semibold">Mathe</span>
          </button>
          <button data-tab="deutsch" class="${cls('deutsch','text-red-600')}">
            <div class="text-3xl mb-1">📘</div>
            <span class="text-xs font-semibold">Deutsch</span>
          </button>
          <button data-tab="englisch" class="${cls('englisch','text-green-600')}">
            <div class="text-3xl mb-1">🌍</div>
            <span class="text-xs font-semibold">Englisch</span>
          </button>
          <button data-tab="profil" class="${cls('profil','text-indigo-600')}">
            <div class="text-3xl mb-1">👤</div>
            <span class="text-xs font-semibold">Profil</span>
          </button>
        </div>
      </div>
    `;
  }

  function render() {
    if (state.isBanned) {
      appElement.innerHTML = renderBanned();
      return;
    }

    if (!state.isLoggedIn) {
      appElement.innerHTML = renderLogin();
      
      if (state.authStep === 'username') {
        const inp = document.getElementById('loginInput');
        if (inp) {
          inp.value = state.loginInput;
          inp.addEventListener('input', (e) => { state.loginInput = e.target.value; });
          inp.addEventListener('keypress', (e) => { if (e.key === 'Enter') handleUsernameSubmit(); });
        }
        const btn = document.getElementById('loginBtn');
        if (btn) btn.addEventListener('click', handleUsernameSubmit);
      } else {
        // PIN pad
        document.querySelectorAll('.pin-btn').forEach(btn => {
          btn.addEventListener('click', (e) => {
            const digit = e.currentTarget.getAttribute('data-digit');
            handlePinInput(digit);
          });
        });
        const delBtn = document.getElementById('pinDelete');
        if (delBtn) delBtn.addEventListener('click', handlePinDelete);
      }
      return;
    }

    // Main view
    appElement.innerHTML = `
      ${renderHeader()}
      <div class="flex-1 overflow-y-auto p-6 pb-24">
        ${state.currentTab === 'profil' ? renderProfile() : ''}
        ${state.currentTab === 'spiele' ? (state.gameActive ? renderGameActive() : state.gameOver ? renderGameOver() : renderGameIntro()) : ''}
        ${(['mathe','deutsch','englisch'].includes(state.currentTab) && state.currentQuestion) ? renderQuestionCard() : ''}
      </div>
      ${renderBottomNav()}
    `;

    // Attach handlers
    const coinEl = document.getElementById('coinCount'); 
    if (coinEl) coinEl.textContent = state.userCoins;

    // Logout button
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) logoutBtn.addEventListener('click', () => {
      if (confirm('Möchtest du dich wirklich ausloggen?')) {
        handleLogout();
      }
    });

    // Game handlers
    const startBtn = document.getElementById('startGameBtn'); 
    if (startBtn) startBtn.addEventListener('click', startFlappyBird);
    
    const tryBtn = document.getElementById('tryAgainBtn'); 
    if (tryBtn) {
      tryBtn.addEventListener('click', () => { 
        state.gameOver = false; 
        if (state.userCoins >= 10) startFlappyBird(); 
      });
    }
    
    const endBtn = document.getElementById('endGameBtn');
    if (endBtn) endBtn.addEventListener('click', endFlappyBird);
    
    const gameCanvas = document.getElementById('gameCanvas');
    if (gameCanvas && state.gameActive) {
      gameCanvas.addEventListener('click', jumpBird);
      gameCanvas.addEventListener('touchstart', (e) => {
        e.preventDefault();
        jumpBird();
      });
    }

    // Answers
    document.querySelectorAll('.answerBtn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const idx = Number(e.currentTarget.getAttribute('data-ans'));
        handleAnswer(idx);
      });
    });

    // Bottom nav
    document.querySelectorAll('[data-tab]').forEach(bt => {
      bt.addEventListener('click', (e) => { 
        handleTabChange(e.currentTarget.getAttribute('data-tab')); 
      });
    });
  }

  // Initial render
  render();

  // Cleanup
  window.addEventListener('beforeunload', () => { 
    stopFlappyBird(); 
  });